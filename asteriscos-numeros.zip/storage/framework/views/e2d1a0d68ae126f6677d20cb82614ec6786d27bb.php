

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <?php $__currentLoopData = $figures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $figure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-header"><?php echo e($figure->name); ?></div>
                    <div class="card-body"><?php echo e(eval('?>' . $figure->code)); ?></div>
                    <div class="card-footer"><?php echo e($figure->user->name); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/figure/figure.blade.php ENDPATH**/ ?>