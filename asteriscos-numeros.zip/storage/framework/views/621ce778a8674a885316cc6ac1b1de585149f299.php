

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if($type && $type != 'categoria' && $category): ?>
                <h1 class="card-header text-center bg-info text-light first-capitalize"><?php echo e($category); ?> hechos con <?php echo e($type); ?></h1>
            <?php elseif($type && $type != 'categoria'): ?>
                <h1 class="card-header text-center bg-info text-light">Figuras hechas con <?php echo e($type); ?></h1>
            <?php elseif($category): ?>
                <h1 class="card-header text-center bg-info text-light text-capitalize"><?php echo e($category); ?></h1>
            <?php else: ?>
                <h1 class="card-header text-center bg-info text-light">Últimas figuras</h1>
            <?php endif; ?>

            <form action="<?php echo e(route('figure.index')); ?>" method="get" class="form form-control bg-light border-0 mb-4">
                <label for="category">Buscar </label>

                <select name="category" class="form-select form-select-index" id="category">
                    <option value="">Todos</option>
                    <option value="cuadrados">Cuadrados</option>
                    <option value="escaleras">Escaleras</option>
                    <option value="picos">Picos</option>
                    <option value="lineas">Líneas</option>
                    <option value="piramides">Pirámides</option>
                    <option value="rombos">Rombos</option>
                    <option value="pentagonos">Pentágonos</option>
                    <option value="estrellas">Estrellas</option>
                    <option value="otros">Otros</option>
                </select>

                <label for="type"> hech@s con </label>

                <select name="type" class="form-select form-select-index" id="type">
                    <option value="categoria">Cualquiera</option>
                    <option value="asteriscos">Asteriscos</option>
                    <option value="numeros">Numeros</option>
                    <option value="otro">Otro</option>
                </select>

                <input type="submit" class="btn-grad btn-grad-sm btn-grad-light ms-2" value="Buscar">
            </form>

            <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if($figures->isEmpty()): ?>
                <div class="card text-center">
                    <div class="card-header bg-info text-light">
                        No hay figuras
                    </div>

                    <div class="card-body bg-light">
                        No se han encontrado figuras con los requisitos solicitados
                    </div>
                </div>
            <?php else: ?>
                <div class="mb-4" id="figure-grid">
                    <?php $__currentLoopData = $figures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $figure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between bg-info">
                                <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('figure.detail', ['id' => $figure->id])); ?>" class="fw-bold text-light mt-1 consolas"><?php echo e($figure->name); ?></a>
                                <?php else: ?>
                                    <?php if($figure->user->id == Auth::user()->id || Auth::user()->role == 'admin'): ?>
                                        <div class="edit">
                                            <a href="<?php echo e(route('figure.edit', ['id' => $figure->id])); ?>"><img src="<?php echo e(asset('img/edit.png')); ?>" alt="Editar"></a>
                                        </div>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('figure.detail', ['id' => $figure->id])); ?>" class="text-light mt-1 fw-bold consolas"><?php echo e($figure->name); ?></a>

                                    <?php if($figure->user->id == Auth::user()->id || Auth::user()->role == 'admin'): ?>
                                        <div class="delete">
                                            <a href="<?php echo e(route('figure.delete', ['id' => $figure->id])); ?>"><img src="<?php echo e(asset('img/delete.png')); ?>" alt="Eliminar"></a>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

                            <div class="card-body bg-light d-flex justify-content-center align-items-center text-dark"><?php echo e(eval('?>' . $figure->code)); ?></div>

                            <div class="d-flex card-footer justify-content-between light-blue">
                                <div class="d-flex">
                                    <div class="image-container">
                                        <img src="<?php echo e(route('user.image', ['filename' => $figure->user->image_path])); ?>" alt="Imagen de perfil">
                                    </div>

                                    <p class="mb-0 mt-1"><?php echo e($figure->user->name); ?></p>
                                </div>

                                <?php if(auth()->guard()->guest()): ?>
                                    <div class="d-flex justify-content-center align-items-center text-center btn-like btn-like-index" href="<?php echo e(route('register')); ?>">
                                        <img src="<?php echo e(asset('img/like-dark.png')); ?>" alt="Like" class="like-symbol">

                                        <p class="text-info mt-1 mb-0 ms-2"><?php echo e(count($figure->likes)); ?></p>
                                    </div>
                                <?php else: ?>
                                    <?php if(array_search($figure->id, $likedFigures)): ?>
                                        <div class="d-flex justify-content-center align-items-center text-center btn-remove-like btn-like-index" data-id="<?php echo e($figure->id); ?>">
                                            <img src="<?php echo e(asset('img/like-blue.png')); ?>" alt="Quitar like" class="remove-like-symbol">

                                            <p class="text-info mt-1 mb-0 ms-2"><?php echo e(count($figure->likes)); ?></p>
                                        </div>
                                    <?php else: ?>
                                        <div class="d-flex justify-content-center align-items-center text-center btn-like btn-like-index" data-id="<?php echo e($figure->id); ?>">
                                            <img src="<?php echo e(asset('img/like-dark.png')); ?>" alt="Like" class="like-symbol">

                                            <p class="text-info mt-1 mb-0 ms-2"><?php echo e(count($figure->likes)); ?></p>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <span><?php echo e($figures->links()); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/figure/index.blade.php ENDPATH**/ ?>