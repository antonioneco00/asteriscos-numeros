<?php if(Auth::user()->image_path): ?>
    <div class="image-container">
        <img src="<?php echo e(route('user.image', ['filename' => Auth::user()->image_path])); ?>" alt="Imagen de usuario" class="image">
    </div>
<?php endif; ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/includes/image.blade.php ENDPATH**/ ?>