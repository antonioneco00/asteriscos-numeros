

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php echo $__env->make('includes/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="card mb-4">
                <div class="card-header text-center bg-info text-light"><h1 class="mb-0 consolas"><?php echo e($figure->name); ?></h1></div>

                <div class="d-flex" id="headers">
                    <div class="card-header w-100 text-center light-blue">Figura</div>
                    <div class="card-header w-100 text-center light-blue">Código</div>
                </div>

                <div class="card-body d-flex align-items-center bg-light">
                    <div class="w-100 text-center" id="figure"><?php echo e(eval('?>' . $figure->code)); ?></div>
                    <div class="w-100" id="code"><?=highlight_string($figure->code, true)?></div>
                </div>

                <div class="d-flex" id="footers">
                    <div class="d-flex justify-content-center align-items-center card-footer w-100 text-light text-center bg-info">Creado por <?php echo e($figure->user->name); ?> hace <?php echo e(\FormatTime::LongTimeFilter($figure->created_at)); ?></div>
                    
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="d-flex justify-content-center align-items-center card-footer w-100 text-center bg-light" href="<?php echo e(route('register')); ?>">
                            Regístrate para dar me gusta
                        </a>
                    <?php else: ?>
                        <?php if($user_like): ?>
                            <a class="d-flex justify-content-center align-items-center card-footer w-100 text-center bg-light btn-remove-like" data-id="<?php echo e($figure->id); ?>" href="#">
                                <p>Likes</p>

                                <img src="<?php echo e(asset('img/like-blue.png')); ?>" alt="Quitar like" class="remove-like-symbol">
                            </a>
                        <?php else: ?>
                            <a class="d-flex justify-content-center align-items-center card-footer w-100 text-center bg-light btn-like" data-id="<?php echo e($figure->id); ?>" href="#">
                                <p>Likes</p>

                                <img src="<?php echo e(asset('img/like-dark.png')); ?>" alt="Like" class="like-symbol">
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <strong>Tipo: </strong><?php echo e($figure->type); ?> <br>
                    <strong>Categoría: </strong><?php echo e($figure->category); ?> <br>
                    <strong>Descripción: </strong><?php echo e($figure->description); ?> <br>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header text-center bg-info">Comentarios</div>

                <div class="card-body">
                    <?php $__currentLoopData = $figure->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="comment">
                            <h2><?php echo e($comment->user->name); ?></h2>
                            <p><?php echo e($comment->content); ?></p>
                        </div>

                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(auth()->guard()->guest()): ?>
                        <h2 class="text-center mb-3">Necesitas registrarte para dejar un comentario</h2>

                        <a href="<?php echo e(route('register')); ?>" class="btn-grad text-center">Registrarse</a>
                    <?php else: ?>
                        <form action="<?php echo e(route('comment.save')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="figure_id" value="<?php echo e($figure->id); ?>">

                            <label for="content"><h2>Añadir comentario</h2></label>

                            <textarea name="content" class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4"></textarea>

                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <input type="submit" value="Enviar" class="btn-grad btn-grad-md btn-grad-light">
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/figure/detail.blade.php ENDPATH**/ ?>