

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-info text-center">Editar figura</div>
                <div class="card-body">
                    <form action="<?php echo e(route('figure.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="figure_id" value="<?php echo e($figure->id); ?>">

                        <div class="form-group row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Nombre</label>

                            <div class="col-md-6">
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($figure->name); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="type" class="col-md-4 col-form-label text-md-end">Tipo</label>

                            <div class="col-md-6">
                                <select name="type" id="type" class="form-select w-100" data-type="<?php echo e($figure->type); ?>" required>
                                    <option value="asteriscos">Asteriscos</option>
                                    <option value="numeros">Numeros</option>
                                    <option value="otro">Otro</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="category" class="col-md-4 col-form-label text-md-end">Categoría</label>

                            <div class="col-md-6">
                                <select name="category" id="category" class="form-select w-100" data-category="<?php echo e($figure->category); ?>" required>
                                    <option value="cuadrados">Cuadrados</option>
                                    <option value="escaleras">Escaleras</option>
                                    <option value="picos">Picos</option>
                                    <option value="lineas">Líneas</option>
                                    <option value="piramides">Pirámides</option>
                                    <option value="rombos">Rombos</option>
                                    <option value="pentagonos">Pentágonos</option>
                                    <option value="estrellas">Estrellas</option>
                                    <option value="otros">Otros</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="code" class="col-md-4 col-form-label text-md-end">Código PHP</label>

                            <div class="col-md-6">
                                <textarea name="code" class="w-100" id="code" rows="12" required><?php echo e($figure->code); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="description" class="col-md-4 col-form-label text-md-end">Descripción (opcional)</label>

                            <div class="col-md-6">
                                <textarea name="description" class="w-100" id="description" rows="5"><?php echo e($figure->description); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <input type="submit" value="Actualizar" class="btn btn-info">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/figure/edit.blade.php ENDPATH**/ ?>