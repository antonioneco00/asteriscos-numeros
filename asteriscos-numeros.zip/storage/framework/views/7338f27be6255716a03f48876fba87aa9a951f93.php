<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/welcome/welcome.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light">
            <?php echo $__env->make('includes/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        
        <div id="welcome">
            <h1 class="display-3 text-center">Bienvenido a la web más amplia de figuras hechas con código</h1>

            <p class="text-center lead">
                ¿Alguna vez te has encontrado con esos ejercicios de programación que consisten en programar figuras
                y que dan tantos quebraderos de cabeza?
                ¡Únete y aprende de una vez por todas!
            </p>
        </div>
        <div class="wave">
            <img src="<?php echo e(asset('img/wave.svg')); ?>" alt="Wave">
        </div>
        <div id="tutorial" class="d-flex flex-row justify-content-evenly text-center">
            <div class="welcome-text-div" id="tutorial-text">
                <h1 class="display-3">Tutorial</h1>

                <p class="lead">
                    En nuestro tutorial aprenderás cómo utilizar los bucles para crear distintas matrices,
                    y según el uso de condicionales, podrás imprimir la figura que desees
                </p>
                <a href="<?php echo e(route('home')); ?>" class="btn-grad btn-grad-md btn-grad-light">
                    Acceder
                </a>
            </div>
            <div class="clearfix"></div>
            <div class="align-self-center" id="tutorial-table">
                <table class="table table-bordered">
                    <tr>
                        <th class="bg-primary text-light">Variables</th>
                        <?php for($j = 0; $j < 5; $j++): ?>
                            <th class="bg-primary text-light">$j = <?php echo e($j); ?></th>
                        <?php endfor; ?>
                    </tr>
                    <?php for($i = 0; $i < 5; $i++): ?>
                        <tr>
                            <th class="bg-primary text-light">$i = <?php echo e($i); ?></th>

                            <?php for($j = 0; $j < 5; $j++): ?>
                                <?php if($i % 2 == 0): ?>
                                    <td class="table-primary"><?php echo e($i + $j); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($i + $j); ?></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </tr>
                    <?php endfor; ?>
                </table>
            </div>
        </div>
        <div class="wave wave-rotate">
            <img src="<?php echo e(asset('img/wave.svg')); ?>" alt="Wave">
        </div>
        <div id="upload" class="d-flex flex-row justify-content-evenly text-center">
            <div class="welcome-text-div" id="upload-text">
                <h1 class="display-3">Subir figuras</h1>

                <p class="lead">
                    También podrás compartir las figuras que aprendas a hacer conforme mejores tus habilidades
                    de programación con bucles y condicionales.
                </p>
                <a href="<?php echo e(route('register')); ?>" class="btn-grad btn-grad-md btn-grad-dark">
                    ¡Únete!
                </a>
            </div>
        </div>
        <div class="wave wave-dark">
            <img src="<?php echo e(asset('img/wave-black.svg')); ?>" alt="Wave">
        </div>
        <footer class="text-light pb-1" id="footer">
            <h1>Desarrollado por Antonio Nevado Contreras &copy;</h1>
        </footer>
    </div>
</body>
</html>
<?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/welcome.blade.php ENDPATH**/ ?>