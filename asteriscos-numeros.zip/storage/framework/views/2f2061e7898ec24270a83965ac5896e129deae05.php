<?php if(session('message')): ?>
    <div class="alert alert-success mb-4">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><?php /**PATH D:\Programacion\wamp64\www\asteriscos-numeros\resources\views/includes/message.blade.php ENDPATH**/ ?>