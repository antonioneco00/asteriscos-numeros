@if (session('message'))
    <div class="alert alert-success mb-4">
        {{session('message')}}
    </div>
@endif